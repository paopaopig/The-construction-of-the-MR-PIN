import numpy as np
import pandas as pd

nodes_names = np.load(r"human\PPI\BIOGRID\gene_name.npy")
SPIN = np.load(r'human\PPI\BIOGRID\SPIN.npy', allow_pickle = True)


nodes_expression_value = np.load(r'human\PPI\BIOGRID\gene_value_profile.npy')

ind_del = [10, 50, 53, 4, 55, 52, 51, 14, 29, 8]
nodes_expression_0 = nodes_expression_value[:,ind_del[0]].reshape(len(nodes_names),1)
nodes_expression_1 = nodes_expression_value[:,ind_del[1]].reshape(len(nodes_names),1)
nodes_expression_2 = nodes_expression_value[:,ind_del[2]].reshape(len(nodes_names),1)
nodes_expression_3 = nodes_expression_value[:,ind_del[3]].reshape(len(nodes_names),1)
nodes_expression_4 = nodes_expression_value[:,ind_del[4]].reshape(len(nodes_names),1)
nodes_expression_5 = nodes_expression_value[:,ind_del[5]].reshape(len(nodes_names),1)
nodes_expression_6 = nodes_expression_value[:,ind_del[6]].reshape(len(nodes_names),1)
nodes_expression_7 = nodes_expression_value[:,ind_del[7]].reshape(len(nodes_names),1)
nodes_expression_8 = nodes_expression_value[:,ind_del[8]].reshape(len(nodes_names),1)
nodes_expression_9 = nodes_expression_value[:,ind_del[9]].reshape(len(nodes_names),1)

nodes_expression_value_new = np.hstack((nodes_expression_0,nodes_expression_1,nodes_expression_2,
                                        nodes_expression_3,nodes_expression_4,nodes_expression_5,
                                        nodes_expression_6,nodes_expression_7,nodes_expression_8,
                                        nodes_expression_9
                                        
                                    ))

#3sigma
def get_threshold(k,after_combine_matrix):
    sigma = np.std(after_combine_matrix,axis = 1,ddof=1)
    mean = np.mean(after_combine_matrix,axis = 1)
    F = 1/(1+sigma**2)
    th = mean+(k*sigma)*(1-F)
    return th
k = 1


yuzhi = get_threshold(k, nodes_expression_value_new)


for i in range(len(nodes_names)):
    for j in range(nodes_expression_value_new.shape[1]):
        if yuzhi[i] < nodes_expression_value_new[i,j]:
            nodes_expression_value_new[i,j] = 1
        else:
            nodes_expression_value_new[i,j] = 0
            

DPIN = np.zeros((len(nodes_names), len(nodes_names)))

for i in range(len(nodes_names)):
    for j in range(i+1,len(nodes_names)):
        if (nodes_expression_value_new[i,:]*nodes_expression_value_new[j,:]).sum()>=1:
            DPIN[i,j] = DPIN[j,i] = 1  
        
DPIN = DPIN * SPIN
print(sum(sum(DPIN))/2)

np.save(r'human\PPI\BIOGRID/FSPIN-10-1.npy',DPIN) 