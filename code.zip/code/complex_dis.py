import numpy as np
import pandas as pd
DPIN = np.load(r"E:\组合中心性方法\biogrid\SPPI邻阶矩阵.npy")
nodes_name=np.load("E:\\组合中心性方法\\biogrid\\5616个节点的名字.npy")
essential=np.load("E:\\组合中心性方法\\biogrid\\1199个关键蛋白质.npy")
fuhewu = np.load(r"F:\基于一次细化的多层网络\复合物中出现的蛋白质.npy")
counttt = np.load(r"F:\基于一次细化的多层网络\复合物中出现蛋白质对应的次数.npy")
genedata=pd.read_excel('C:\\Users\\Lenovo\\Desktop\\complex.XLSX',header=None)
genedata=np.array(genedata)

comp_f=[]
for i in range(745):
    comp=[]
    for j in range(559):
        if genedata[i,j]!='nan' and type(genedata[i,j])!=float:
            comp.append(genedata[i,j])
    comp_f.append(comp)

for i in range(5616):
    for j in range(i+1,5616):
        if DPIN[i,j] == 1:
            flag=0
            ttt1=0
            ttt2=0
            if nodes_name[i] in fuhewu or nodes_name[j] in fuhewu:
                for k in range(len(fuhewu)):
                #if nodes_name[i] in comp_f[k] and nodes_name[j] in comp_f[k]:
                    if nodes_name[i]==fuhewu[k]:
                        ttt1=int(counttt[k])
                    if nodes_name[j]==fuhewu[k]:
                        ttt2=int(counttt[k])
            if ttt1>=1 and ttt2>=1:
                flag=1
            if flag==0:
                DPIN[i,j]=DPIN[j,i]=0
np.save(r"F:\deep=GAT\出现在复合物中过-biogrid-complex.npy",DPIN)
print(sum(sum(DPIN))/2)