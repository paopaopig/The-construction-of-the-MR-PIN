import numpy as np
import pandas as pd
import scipy.spatial.distance as dist 
def jdc(Dis, nodes_name, gene_value):
    gene_value = gene_value.astype("float64")
    degree = np.sum(Dis,axis = 1)
    E_mean = np.zeros(len(nodes_name))
    E_mean = np.mean(gene_value,axis = 1)
    E_sigma = np.zeros(len(nodes_name))
    E_sigma = np.std(gene_value,axis = 1,ddof=1)
    E_var = np.zeros(len(nodes_name))
    E_var = np.var(gene_value,axis = 1,ddof=1)
    T = E_var/(E_var+1)
    G = E_mean + 2*E_sigma*T
    A = np.zeros((len(nodes_name),36))
    for i in range(len(nodes_name)):
        for j in range(36):
            if gene_value[i,j]>G[i]:
                A[i,j] = 1


    Ecc = np.zeros((len(nodes_name),len(nodes_name)))
    PeC_J = np.zeros((len(nodes_name),len(nodes_name)))
    J = np.float32(np.zeros((len(nodes_name),len(nodes_name))))
    z = np.zeros((len(nodes_name),len(nodes_name)))
    m = np.zeros((len(nodes_name),len(nodes_name)))
    for i in range(len(nodes_name)):
        for j in range(len(nodes_name)):
            if Dis[i,j] == 1 and i != j:
                D = np.mat([A[i,:],A[j,:]])
                J[i,j] = np.float32(1-dist.pdist(D,'jaccard')[0])
                temp = 0
                for k in range(len(nodes_name)):
                    if Dis[i,k] == 1 and Dis[j,k] ==1 and i!=j!=k:
                        temp+=1
                z[i,j] = temp
                m[i,j] = min(degree[i]-1,degree[j]-1)
                Ecc[i,j] = z[i,j]/m[i,j]
                PeC_J[i,j] = Ecc[i,j]*J[i,j]

    PeC_J[np.isnan(PeC_J)==1]=0
    lc = np.sum(PeC_J,axis = 1)
    return lc





