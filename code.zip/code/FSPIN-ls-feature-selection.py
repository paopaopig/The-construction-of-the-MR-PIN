'''
输入 len_a：蛋白质节点个数 4746,5093
    static_ppinet：静态蛋白质相互作用网络
    ttt:对应蛋白质节点有的基因表达水平数据值 如4746*36
    tp：时点个数
    
输出  result：前1-tp个为时点排序，最后一位为ls算法中α的值

'''

import numpy as np
import math
from scipy.spatial.distance import pdist

def LS_gene_timpoints_rank(len_a,ttt,static_ppinet,tp):
    result=np.empty(shape=[0,tp+1])
    for t in np.arange(0.1,0.2,0.1):
        s=np.zeros(shape=(len_a,len_a))
        for i in range(len_a):
    
            for j in range(i+1,len_a):
                if static_ppinet[i,j]==1:
                    ppp=ttt-np.mean(ttt,axis=1).reshape(len_a,1)
                    dis=pdist(np.vstack([ppp[i,:], ppp[j,:]]),'euclidean')
                    a=math.e**(-dis/t)
                    s[i,j]=a
                    s[j,i]=a
        L=[]
        for r in range(tp):
            total_sum=0
            for i in range(len_a):
                for j in range(i+1,len_a):
                    sum_1=((ppp[i,r]-ppp[j,r])**2)*s[i,j]
                    total_sum=total_sum+sum_1  
            D_sum=np.sum(s)
            sum_temp=0
            for o in range(len_a):
                D=np.sum(s[o,:],axis=0)
                sum_temp=(ppp[o,r]*D)+sum_temp
            u=sum_temp/D_sum
            Var=0
            for h in range(len_a):
                temp=((ppp[h,r]-u)**2)*np.sum(s[h,:],axis=0)
                Var=Var+temp
            L.append(total_sum/Var)
        sort=sorted(range(len(L)), key=lambda k: L[k])
        sort.append(t)
        print('t={}'.format(t),sort)
        result=np.append(result,np.array(sort).reshape(1,tp+1),axis=0)
    return result
gene=np.load(r'F:\human\PPI\BIOGRID\gene_value_profile.npy')
sppi=np.load(r'F:\human\PPI\BIOGRID\SPIN.npy')
tp=64
ls_result=LS_gene_timpoints_rank(16562,gene,sppi,tp)