import numpy as np
import pandas as pd
import networkx as nx
from math import *
from sklearn import preprocessing
from sklearn import metrics
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import auc
from JDC_method import jdc
from network_based_centralities import lac,nc,dmnc,tp,lid,clc,dc,ec,cc,bc,pr
result_f = pd.DataFrame(columns=['p','q','top100','top600','top_ess_num'], index=None)
SSSS=0
nodes_names = np.load(r"human/PPI/DIP/gene_name.npy")
essential_nodes_name=np.load(r"human/PPI/DIP/ess_gene_name.npy")
sub_dis = np.load(r'human/PPI/DIP/sub_dis.npy')
gene_value = np.load(r'human/PPI/DIP/gene_value_profile.npy')

lc2 = jdc(sub_dis, nodes_names, gene_value)
min_max_scaler = preprocessing.MinMaxScaler()
X_minMax2 = min_max_scaler.fit_transform(np.array(lc2).reshape(-1, 1))

for p in range(50,151,25):
    X_minMax1 = np.load(r"human/PPI/DIP/jdc/lc1-k=%.2f.npy"%(p/100))
    
    for q in range(25,61,5):
        X_minMax4 = np.load(r"human/PPI/DIP/jdc/lc4-q=%d.npy"%(q))
        
        print("p=",p/100," ; ","q=",q)
        
        
              
        c_02= np.hstack((X_minMax1,X_minMax2,X_minMax4))

        for d in range(3):
            c_02[:,d] = (c_02[:,d]+0.001)/(1+0.001)
        
        lc =(np.array(c_02[:,0]))*(np.array(c_02[:,1]))*(np.array(c_02[:,2]))
        
        ec_val=pd.DataFrame(lc,index=nodes_names)
        aaa=ec_val.sort_values(by = 0,axis = 0,ascending = False)
        
        #计算ROC-AUC
        nodes=[]
        nodes=np.array(aaa.index)
        pred=np.arange(len(nodes_names),0,-1)
        
        y=np.zeros(len(nodes_names))
        
        for i in range(len(nodes_names)):
            for j in range(len(essential_nodes_name)):
                if(nodes[i]==essential_nodes_name[j]):
                    y[i]=1       
        
        #roc-auc
        fpr,tpr,thresholds = metrics.roc_curve(y , aaa.values) 
        ROC_AUC = metrics.auc(fpr,tpr)           
        print("ROC-AUC= %.4f" % metrics.auc(fpr,tpr))
        #pr-auc
        lr_precision, lr_recall, thresholds = precision_recall_curve(y, aaa.values)
        lr_auc = auc(lr_recall, lr_precision)
        PR_AUC = (lr_auc)
        print('PR-AUC = %.4f' % (lr_auc))
        
        edgelist_new=[]
        edgelist_new=np.array(aaa.index)
        
        
        edgelist_new600=[]
        edgelist_new600=edgelist_new[:len(essential_nodes_name)]
        essential = np.array(edgelist_new600)
        
        all= []
        all100=[]
        
        all200=[]
        all300=[]
        all400=[]
        all500=[]
       
        all600=[]
        all1130=[]
        
        ess100=essential[:100]
        
        ess200=essential[:200]
        ess300=essential[:300]
        ess400=essential[:400]
        ess500=essential[:500]
        
        ess600=essential[:600]
        ess1130=essential[:len(essential_nodes_name)]
        
        for id in essential_nodes_name:
            if id in ess100:
                all100.append(id)
        print('top100:',len(all100))
       
        for id in essential_nodes_name:
            if id in ess200:
                all200.append(id)
        for id in essential_nodes_name:
            if id in ess300:
                all300.append(id)
        for id in essential_nodes_name:
            if id in ess400:
                all400.append(id)
        for id in essential_nodes_name:
            if id in ess500:
                all500.append(id)
        print('top200-top500:',len(all200),len(all300),len(all400),len(all500))
      
        for id in essential_nodes_name:
            if id in ess600:
                all600.append(id)
        print('top600:',len(all600))
        for id in essential_nodes_name:
            if id in ess1130:
                all1130.append(id)
        print('top1130:',len(all1130))
        result_f.loc[SSSS] = [p/100,q,len(all100),len(all600),len(all1130)]
        SSSS+=1
