import numpy as np
import pandas as pd
nodes_names = np.load(r"human/PPI/BIOGRID/gene_name.npy")
SPIN = np.load(r'human/PPI/BIOGRID/SPIN.npy', allow_pickle = True)

orthologs = pd.read_csv(r'human/Orthologs/orthologs.csv')
gene_name=np.array(orthologs['Gene'])
gene_orthologs_values=np.array(orthologs.iloc[:,:-1])

nodes_orthologs_value=[]
k=0
for i in range(len(nodes_names)):
    flag = 0
    if nodes_names[i] in gene_name:    
        ind = np.argwhere(gene_name == nodes_names[i])
        #print(ind)
        flag += 1
        k=k+1
        nodes_orthologs_value.append(gene_orthologs_values[ind[0,0],:])
    if flag == 0:
         nodes_orthologs_value.append(np.zeros(gene_orthologs_values.shape[1]))
        
nodes_orthologs_value = np.array(nodes_orthologs_value)
nodes_orthologs_score = np.sum(nodes_orthologs_value, axis=1)

yuzhi = 40
ORTH_PIN = np.zeros((len(nodes_names), len(nodes_names)))
for i in range(len(nodes_names)):
    for j in range(i+1, len(nodes_names)):
        if (nodes_orthologs_value[i,:]*nodes_orthologs_value[j,:]).sum() >= 1 and nodes_orthologs_score[i]>=yuzhi and nodes_orthologs_score[j]>=yuzhi:
            ORTH_PIN[i,j] = ORTH_PIN[j,i] = 1
            
ORTH_PIN = ORTH_PIN * SPIN
print(sum(sum(ORTH_PIN))/2)
np.save(r'human/PPI/BIOGRID/orth_dis_q=40.npy',ORTH_PIN)  