import numpy as np
import pandas as pd

nodes_names = np.load(r"human/PPI/DIP/gene_name.npy")
SPIN = np.load(r'human/PPI/DIP/SPIN.npy', allow_pickle = True)

genedata = pd.read_csv(r'human/Expression/profile.csv')
gene_expression_name = np.array(genedata.iloc[:,0])
gene_expression_value = np.array(genedata.iloc[:,1:])
nodes_expression_value=[]
k=0
for i in range(len(nodes_names)):
    flag = 0
    if nodes_names[i] in gene_expression_name:    
        ind = np.argwhere(gene_expression_name == nodes_names[i])
        #print(ind)
        flag += 1
        k=k+1
        nodes_expression_value.append(gene_expression_value[ind[0,0],:])
    if flag == 0:
         nodes_expression_value.append(np.zeros(gene_expression_value.shape[1]))
        
nodes_expression_value = np.array(nodes_expression_value)


#3sigma
def get_threshold(k,after_combine_matrix):
    sigma = np.std(after_combine_matrix,axis = 1,ddof=1)
    mean = np.mean(after_combine_matrix,axis = 1)
    F = 1/(1+sigma**2)
    th = mean+(k*sigma)*(1-F)
    return th
k = 0.5


yuzhi = get_threshold(k, nodes_expression_value)


for i in range(len(nodes_names)):
    for j in range(gene_expression_value.shape[1]):
        if yuzhi[i] < nodes_expression_value[i,j]:
            nodes_expression_value[i,j] = 1
        else:
            nodes_expression_value[i,j] = 0
            

DPIN = np.zeros((len(nodes_names), len(nodes_names)))

for i in range(len(nodes_names)):
    for j in range(i+1,len(nodes_names)):
        if (nodes_expression_value[i,:]*nodes_expression_value[j,:]).sum()>=1:
            DPIN[i,j] = DPIN[j,i] = 1  
        
DPIN = DPIN * SPIN
print(sum(sum(DPIN))/2)
np.save(r'human/PPI/DIP/DPIN_and_RDPIN/DPIN-k=0.5.npy',DPIN)     
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    