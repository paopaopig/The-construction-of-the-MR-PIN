import numpy as np
import pandas as pd
nodes_names = np.load(r"human/PPI/BIOGRID/gene_name.npy")
SPIN = np.load(r'human/PPI/BIOGRID/SPIN.npy', allow_pickle = True)

sublocation = pd.read_csv(r'human/SubLocalizations/subloc.csv')
gene_name=np.array(sublocation.iloc[:,0])
subcell_nuc=np.array(sublocation.iloc[:,2])

k=0
nodes_nucleus = []
for i in range(len(nodes_names)):
    flag = 0
    if nodes_names[i] in gene_name:
        ind = np.argwhere(gene_name == nodes_names[i])
        flag += 1
        k=k+1
        nodes_nucleus.append(subcell_nuc[ind[0,0]])
    if flag == 0:
         nodes_nucleus.append(0)

nodes_nucleus = np.array(nodes_nucleus)

SUB_PIN = np.zeros((len(nodes_names), len(nodes_names)))
for i in range(len(nodes_names)):
    for j in range(i+1, len(nodes_names)):
        if nodes_nucleus[i] == 1 and nodes_nucleus[j] == 1:
            SUB_PIN[i,j] = SUB_PIN[j,i] = 1
SUB_PIN = SUB_PIN * SPIN

np.save(r'human/PPI/BIOGRID/sub_dis.npy',SUB_PIN)    
            